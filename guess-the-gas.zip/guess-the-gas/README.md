# Guess the Gas
Mini game untuk ETH holder menebak GWEI harian.