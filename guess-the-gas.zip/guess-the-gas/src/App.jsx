// App component placeholder
export default function App() { return <div>Guess the Gas Game</div>; }